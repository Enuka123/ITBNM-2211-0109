/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.swing.JOptionPane;
import model.DBInsert;

/**
 *
 * @author Gayashan
 */
public class Insertcontroller {
    
    public static void Add(String ID, String Name, String NIC ,String DOB, String Address ,String Password) {
        
       
            new model.DBInsert().Add(ID, Name, NIC, DOB, Address, Password);
            JOptionPane.showMessageDialog(null, " Data stores successfully ", "Successfull",JOptionPane.INFORMATION_MESSAGE);

        }
    
    public static void Additem(String PartNum, String VehicleModel, String PartName ,String Price, String Quantity ) {
        
       
            new model.DBInsert().Additem(PartNum, VehicleModel, PartName ,Price, Quantity );
            JOptionPane.showMessageDialog(null, " Data stores successfully ", "Successfull",JOptionPane.INFORMATION_MESSAGE);

        }
}
