/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.swing.JOptionPane;
import model.Updateform;



/**
 *
 * @author Gayashan
 */
public class Updatecontroller {
    
    public static void Updateform(String cId,String cName,String cNic,String cDob,String cAddress){
    
    new Updateform().Updateform(cId, cName, cNic, cDob, cAddress);
    
    if(cId.equals("")){
    
    
    }
    else{
        JOptionPane.showMessageDialog(null, "Update Successfully!","successfull",JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    
    }
    
}
