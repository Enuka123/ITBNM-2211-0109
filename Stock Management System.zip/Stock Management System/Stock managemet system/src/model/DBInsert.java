/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Statement;

/**
 *
 * @author Gayashan
 */
public class DBInsert {
    
    Statement stmt;
    
    public void Add(String ID, String Name, String NIC ,String DOB, String Address ,String Password){
        try{
            stmt = DBconnect.getStatementConnection();
            stmt.executeUpdate("INSERT INTO adminlogin VALUES('"+ID+"', '"+Name+"', '"+NIC+"', '"+DOB+"','"+Address+"', '"+Password+"')");
        }
        catch (Exception e){
            e.printStackTrace();
        }  
        
    }
    
     public void Additem(String PartNum, String VehicleModel, String PartName ,String Price, String Quantity ){
        try{
            stmt = DBconnect.getStatementConnection();
            stmt.executeUpdate("INSERT INTO inventory VALUES('"+PartNum+"','"+VehicleModel+"', '"+PartName+"', '"+Price+"', '"+Quantity+"')");
        }
        catch (Exception e){
            e.printStackTrace();
        }  
        
    }
}
