/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Gayashan
 */
public class DBSearch {
    
    Statement stmt;
    ResultSet rs;
    
    public ResultSet searchadminloging(String ID){
    try{
        stmt = DBconnect.getStatementConnection();
        String UserID = ID;//Execute Quary
        rs = stmt.executeQuery("SELECT * FROM adminlogin WHERE adminId='"+UserID+"'");
    }
    catch (Exception e){
        e.printStackTrace();
    }return rs;
}
    
    
    
    public ResultSet searchcashierlogin(String ID){
        try{
            stmt = DBconnect.getStatementConnection();
            String CUserID= ID;
            rs = stmt.executeQuery("SELECT * FROM cashier WHERE cashier_id='"+CUserID+"' ");
        }
        catch (Exception e){
            e.printStackTrace();
        }return rs;
    
    
    }
    
   public ResultSet searchallCashier(){
    
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            stmt = DBconnect.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM cashier");
        } catch (Exception e) {
        }
    return rs;
    }
     public ResultSet searchCashier(String  cashierID){
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
             stmt = DBconnect.getStatementConnection();
             
             rs = stmt.executeQuery("SELECT * FROM cashier WHERE cashier_id = '"+cashierID+"'");
             
             
          
        } catch (Exception e) {
        }
        return rs;

    
    
    //public static void main(String[] args) {
        // TODO code application logic here
    }
}
