/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Statement;

/**
 *
 * @author Gayashan
 */
public class Updateform {
    
    Statement stmt;
    
    public void Updateform(String cId,String cName,String cNic,String cDob,String cAddress){
    
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            stmt = DBconnect.getStatementConnection();
            
            
             stmt.executeUpdate("UPDATE cashier SET name = '"+cName+"',nic='"+cNic+"',dob='"+cDob+"',Address='"+cAddress+"' WHERE cashier_id='"+cId+"' ");

        } catch (Exception e) {
        }
    
    
    }
    
}
